[知乎](https://zhuanlan.zhihu.com/p/37189203)
![[人工智能──稠密连接网络.webp]]
