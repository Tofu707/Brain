有这么几个方法：
1. [[预测下一个语素 next-token-prodiction]]
2. [[监督训练微调 Supervised Fintune]]
3. [[人类反馈强化 RLHF]]